import tkinter as tk
from tkinter import (ttk, filedialog, messagebox)
import math
import copy

class Semarbroka3DEditor:
    def __init__(self, root):
        self.root = root
        self.root.title('Semarbroka 3D Mesh Editor (.obj / .sm3d)')
        self.root.geometry('1240x760')
        self.cam_yaw = 0.65
        self.cam_pitch = 0.45
        self.cam_dist = 12.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.fov = 520.0
        self.last_mouse = None
        self.mouse_mode = None
        self.vertices = []
        self.edges = []
        self.faces = []
        self.selected_vertex = -1
        self.current_file = ''
        self.undo_stack = []
        self.redo_stack = []
        self.root.bind('<Control-z>', (lambda e: self.undo()))
        self.root.bind('<Control-Z>', (lambda e: self.undo()))
        self.root.bind('<Control-y>', (lambda e: self.redo()))
        self.root.bind('<Control-Y>', (lambda e: self.redo()))
        self._build_menu()
        self._build_ui()
        self.create_cube(size=2.0, record=False)

    def _build_menu(self):
        menubar = tk.Menu(self.root)
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label='New Scene (Clear)', command=self.clear_scene)
        file_menu.add_command(label='Import Wavefront (.obj)...', command=self.import_obj)
        file_menu.add_command(label='Export Wavefront (.obj)...', command=self.export_obj)
        file_menu.add_separator()
        file_menu.add_command(label='Exit', command=self.root.quit)
        menubar.add_cascade(label='File', menu=file_menu)
        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label='Undo (Ctrl+Z)', command=self.undo)
        edit_menu.add_command(label='Redo (Ctrl+Y)', command=self.redo)
        menubar.add_cascade(label='Edit', menu=edit_menu)
        create_menu = tk.Menu(menubar, tearoff=0)
        create_menu.add_command(label='Add Cube (2x2x2)', command=(lambda: self.create_cube(2.0)))
        create_menu.add_command(label='Add Plane / Road Grid (4x4)', command=(lambda: self.create_plane(4.0)))
        create_menu.add_command(label='Add Pyramid', command=(lambda: self.create_pyramid(2.5)))
        menubar.add_cascade(label='Create Mesh', menu=create_menu)
        self.root.config(menu=menubar)

    def _build_ui(self):
        top_bar = tk.Frame(self.root, bd=1, relief=tk.SUNKEN, padx=6, pady=4)
        top_bar.pack(side=tk.TOP, fill=tk.X)
        self.lbl_status_top = tk.Label(top_bar, text='Scene: Default Cube | Vertices: 8 | Faces: 6', anchor='w')
        self.lbl_status_top.pack(side=tk.LEFT, fill=tk.X, expand=True)
        tk.Button(top_bar, text='+ Cube', command=(lambda: self.create_cube(2.0))).pack(side=tk.RIGHT, padx=3)
        tk.Button(top_bar, text='Redo (Ctrl+Y)', command=self.redo).pack(side=tk.RIGHT, padx=3)
        tk.Button(top_bar, text='Undo (Ctrl+Z)', command=self.undo).pack(side=tk.RIGHT, padx=3)
        tk.Button(top_bar, text='+ Plane', command=(lambda: self.create_plane(4.0))).pack(side=tk.RIGHT, padx=3)
        tk.Button(top_bar, text='Reset Camera', command=self.reset_camera).pack(side=tk.RIGHT, padx=3)
        main_pane = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, sashrelief=tk.RAISED)
        main_pane.pack(fill=tk.BOTH, expand=True)
        left_frame = tk.Frame(main_pane)
        main_pane.add(left_frame, width=820)
        self.canvas = tk.Canvas(left_frame, bg='#26292E', cursor='crosshair')
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind('<Button-1>', self.on_left_click)
        self.canvas.bind('<ButtonPress-3>', (lambda e: self.start_drag(e, 'orbit')))
        self.canvas.bind('<B3-Motion>', self.on_drag)
        self.canvas.bind('<ButtonPress-2>', (lambda e: self.start_drag(e, 'pan')))
        self.canvas.bind('<B2-Motion>', self.on_drag)
        self.canvas.bind('<MouseWheel>', self.on_zoom)
        self.canvas.bind('<Configure>', (lambda e: self.redraw()))
        table_frame = tk.Frame(left_frame, height=180)
        table_frame.pack(side=tk.BOTTOM, fill=tk.X)
        cols = ('id', 'x', 'y', 'z')
        self.tree = ttk.Treeview(table_frame, columns=cols, show='headings', height=6)
        for col, title, w in (('id', 'Vertex ID', 90), ('x', 'Pos X', 160), ('y', 'Pos Y (Height)', 160), ('z', 'Pos Z', 160)):
            self.tree.heading(col, text=title)
            self.tree.column(col, width=w, anchor='e')
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.tree.bind('<<TreeviewSelect>>', self.on_table_select)
        sb = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        right_frame = tk.Frame(main_pane, padx=14, pady=12, bg='#E6E4E0')
        main_pane.add(right_frame, width=400)
        tk.Label(right_frame, text='3D Mesh & Vertex Inspector', font=('Segoe UI', 11, 'bold'), bg='#E6E4E0').grid(row=0, column=0, columnspan=2, sticky='w', pady=(0, 10))
        tk.Label(right_frame, text='Selected Vertex Coordinates:', font=('Segoe UI', 9, 'bold'), bg='#E6E4E0').grid(row=1, column=0, columnspan=2, sticky='w', pady=(6, 4))
        self.var_vx = tk.StringVar(value='0.0')
        self.var_vy = tk.StringVar(value='0.0')
        self.var_vz = tk.StringVar(value='0.0')
        for r, lbl, var in (2, 'Vertex X :', self.var_vx), (3, 'Vertex Y :', self.var_vy), (4, 'Vertex Z :', self.var_vz):
            tk.Label(right_frame, text=lbl, bg='#E6E4E0').grid(row=r, column=0, sticky='e', padx=6, pady=3)
            tk.Entry(right_frame, textvariable=var, width=18).grid(row=r, column=1, sticky='w', pady=3)
        tk.Button(right_frame, text='Apply Vertex Position', bg='#D0E8D0', width=24, command=self.apply_vertex_edit).grid(row=5, column=0, columnspan=2, pady=8)
        ttk.Separator(right_frame, orient='horizontal').grid(row=6, column=0, columnspan=2, sticky='ew', pady=10)
        tk.Label(right_frame, text='Global Object Transform:', font=('Segoe UI', 9, 'bold'), bg='#E6E4E0').grid(row=7, column=0, columnspan=2, sticky='w', pady=(2, 6))
        move_frame = tk.Frame(right_frame, bg='#E6E4E0')
        move_frame.grid(row=8, column=0, columnspan=2, sticky='w', pady=3)
        tk.Label(move_frame, text='Move:', width=7, anchor='w', bg='#E6E4E0').pack(side=tk.LEFT)
        tk.Button(move_frame, text='X +0.5', command=(lambda: self.translate_mesh(0.5, 0, 0))).pack(side=tk.LEFT, padx=2)
        tk.Button(move_frame, text='X -0.5', command=(lambda: self.translate_mesh(-0.5, 0, 0))).pack(side=tk.LEFT, padx=2)
        tk.Button(move_frame, text='Y +0.5', command=(lambda: self.translate_mesh(0, 0.5, 0))).pack(side=tk.LEFT, padx=2)
        tk.Button(move_frame, text='Z +0.5', command=(lambda: self.translate_mesh(0, 0, 0.5))).pack(side=tk.LEFT, padx=2)
        rot_frame = tk.Frame(right_frame, bg='#E6E4E0')
        rot_frame.grid(row=9, column=0, columnspan=2, sticky='w', pady=3)
        tk.Label(rot_frame, text='Rotate:', width=7, anchor='w', bg='#E6E4E0').pack(side=tk.LEFT)
        tk.Button(rot_frame, text='Rot Y +15', command=(lambda: self.rotate_mesh_y(15))).pack(side=tk.LEFT, padx=2)
        tk.Button(rot_frame, text='Rot Y -15', command=(lambda: self.rotate_mesh_y(-15))).pack(side=tk.LEFT, padx=2)
        tk.Button(rot_frame, text='Rot X +15', command=(lambda: self.rotate_mesh_x(15))).pack(side=tk.LEFT, padx=2)
        scl_frame = tk.Frame(right_frame, bg='#E6E4E0')
        scl_frame.grid(row=10, column=0, columnspan=2, sticky='w', pady=3)
        tk.Label(scl_frame, text='Scale:', width=7, anchor='w', bg='#E6E4E0').pack(side=tk.LEFT)
        tk.Button(scl_frame, text='Scale 1.2x', command=(lambda: self.scale_mesh(1.2))).pack(side=tk.LEFT, padx=2)
        tk.Button(scl_frame, text='Scale 0.8x', command=(lambda: self.scale_mesh(0.8))).pack(side=tk.LEFT, padx=2)
        self.var_show_wire = tk.BooleanVar(value=True)
        self.var_show_verts = tk.BooleanVar(value=True)
        self.var_show_faces = tk.BooleanVar(value=True)
        tk.Checkbutton(right_frame, text='Show Shaded Faces', variable=self.var_show_faces, bg='#E6E4E0', command=self.redraw).grid(row=11, column=0, columnspan=2, sticky='w', pady=(10, 0))
        tk.Checkbutton(right_frame, text='Show Wireframe Edges', variable=self.var_show_wire, bg='#E6E4E0', command=self.redraw).grid(row=12, column=0, columnspan=2, sticky='w')
        tk.Checkbutton(right_frame, text='Show Vertices (Points)', variable=self.var_show_verts, bg='#E6E4E0', command=self.redraw).grid(row=13, column=0, columnspan=2, sticky='w')
        tips = 'Kontrol 3D Viewport:\n- Klik Kiri: Pilih titik Vertex (merah)\n- Klik Kanan + Geser: Putar kamera (Orbit)\n- Klik Tengah + Geser: Geser layar (Pan)\n- Scroll Mouse: Zoom In / Out\n- Ctrl+Z / Ctrl+Y: Undo / Redo'
        tk.Label(right_frame, text=tips, justify='left', bg='#E6E4E0', fg='#333333').grid(row=14, column=0, columnspan=2, sticky='w', pady=(16, 0))

    def save_state(self):
        state = copy.deepcopy(self.vertices), copy.deepcopy(self.edges), copy.deepcopy(self.faces), self.selected_vertex
        self.undo_stack.append(state)
        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if not self.undo_stack:
            return
        current = copy.deepcopy(self.vertices), copy.deepcopy(self.edges), copy.deepcopy(self.faces), self.selected_vertex
        self.redo_stack.append(current)
        self.vertices, self.edges, self.faces, self.selected_vertex = self.undo_stack.pop()
        self.refresh_all()

    def redo(self):
        if not self.redo_stack:
            return
        current = copy.deepcopy(self.vertices), copy.deepcopy(self.edges), copy.deepcopy(self.faces), self.selected_vertex
        self.undo_stack.append(current)
        self.vertices, self.edges, self.faces, self.selected_vertex = self.redo_stack.pop()
        self.refresh_all()

    def clear_scene(self):
        self.save_state()
        self.vertices.clear()
        self.edges.clear()
        self.faces.clear()
        self.selected_vertex = -1
        self.refresh_all()

    def create_cube(self, size=2.0, record=True):
        if record:
            self.save_state()
        s = size / 2.0
        base = len(self.vertices)
        self.vertices.extend([[-s, -s, -s], [s, -s, -s], [s, s, -s], [-s, s, -s], [-s, -s, s], [s, -s, s], [s, s, s], [-s, s, s]])
        for a, b in ((0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)):
            self.edges.append((base + a, base + b))
        for f in ((0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4), (2, 3, 7, 6), (1, 2, 6, 5), (0, 3, 7, 4)):
            self.faces.append([base + i for i in f])
        self.refresh_all()

    def create_plane(self, size=4.0):
        self.save_state()
        s = size / 2.0
        base = len(self.vertices)
        self.vertices.extend([[-s, 0.0, -s], [s, 0.0, -s], [s, 0.0, s], [-s, 0.0, s]])
        for a, b in ((0, 1), (1, 2), (2, 3), (3, 0)):
            self.edges.append((base + a, base + b))
        self.faces.append([base, base + 1, base + 2, base + 3])
        self.refresh_all()

    def create_pyramid(self, size=2.5):
        self.save_state()
        s = size / 2.0
        base = len(self.vertices)
        self.vertices.extend([[-s, 0.0, -s], [s, 0.0, -s], [s, 0.0, s], [-s, 0.0, s], [0.0, size, 0.0]])
        for a, b in ((0, 1), (1, 2), (2, 3), (3, 0), (0, 4), (1, 4), (2, 4), (3, 4)):
            self.edges.append((base + a, base + b))
        for f in ((0, 1, 2, 3), (0, 1, 4), (1, 2, 4), (2, 3, 4), (3, 0, 4)):
            self.faces.append([base + i for i in f])
        self.refresh_all()

    def project_3d(self, x, y, z):
        cos_y, sin_y = math.cos(self.cam_yaw), math.sin(self.cam_yaw)
        x1 = x * cos_y - z * sin_y
        z1 = x * sin_y + z * cos_y
        cos_p, sin_p = math.cos(self.cam_pitch), math.sin(self.cam_pitch)
        y2 = y * cos_p - z1 * sin_p
        z2 = y * sin_p + z1 * cos_p
        z_cam = max(0.2, z2 + self.cam_dist)
        w = self.canvas.winfo_width() or 820
        h = self.canvas.winfo_height() or 540
        return w / 2.0 + self.pan_x + x1 * self.fov / z_cam, h / 2.0 + self.pan_y - y2 * self.fov / z_cam, z_cam

    def redraw(self):
        self.canvas.delete('all')
        for i in range(-5, 6):
            x1, y1, _ = self.project_3d(i, 0, -5)
            x2, y2, _ = self.project_3d(i, 0, 5)
            self.canvas.create_line(x1, y1, x2, y2, fill='#4A525D' if i != 0 else '#3A6EA5', width=1)
            x3, y3, _ = self.project_3d(-5, 0, i)
            x4, y4, _ = self.project_3d(5, 0, i)
            self.canvas.create_line(x3, y3, x4, y4, fill='#4A525D' if i != 0 else '#C04040', width=1)
        projected = [self.project_3d(*v) for v in self.vertices]
        if self.var_show_faces.get() and self.faces:
            sorted_faces = []
            for f in self.faces:
                if all((idx < len(projected) for idx in f)):
                    z_vals = []
                    for idx in f:
                        _, _, z_val = projected[idx]
                        z_vals.append(z_val)
                    avg_z = sum(z_vals) / len(f)
                    sorted_faces.append((avg_z, f))
            sorted_faces.sort(reverse=True)
            for avg_z, f in sorted_faces:
                pts = []
                for idx in f:
                    sx, sy, _ = projected[idx]
                    pts.extend([sx, sy])
                shade = max(75, min(155, int(190 - avg_z * 6)))
                self.canvas.create_polygon(pts, fill='#{:02x}{:02x}{:02x}'.format(shade, shade + 8, shade + 18), outline='')
        if self.var_show_wire.get():
            for a, b in self.edges:
                if a < len(projected) and b < len(projected):
                    x1, y1, _ = projected[a]
                    x2, y2, _ = projected[b]
                    self.canvas.create_line(x1, y1, x2, y2, fill='#00D8FF', width=1.5)
        if self.var_show_verts.get():
            for idx, (sx, sy, _) in enumerate(projected):
                is_sel = idx == self.selected_vertex
                r = 6 if is_sel else 3.5
                self.canvas.create_oval(sx - r, sy - r, sx + r, sy + r, fill='#FF3333' if is_sel else '#FFCC00', outline='#111111')

    def start_drag(self, event, mode):
        self.last_mouse = event.x, event.y
        self.mouse_mode = mode

    def on_drag(self, event):
        if not self.last_mouse:
            return
        lx, ly = self.last_mouse
        dx, dy = event.x - lx, event.y - ly
        self.last_mouse = event.x, event.y
        if self.mouse_mode == 'orbit':
            self.cam_yaw += dx * 0.01
            self.cam_pitch = max(-1.5, min(1.5, self.cam_pitch + dy * 0.01))
        elif self.mouse_mode == 'pan':
            self.pan_x += dx
            self.pan_y += dy
        self.redraw()

    def on_zoom(self, event):
        self.cam_dist = max(2.0, min(60.0, self.cam_dist * (0.9 if event.delta > 0 else 1.1)))
        self.redraw()

    def reset_camera(self):
        self.cam_yaw, self.cam_pitch, self.cam_dist, self.pan_x, self.pan_y = 0.65, 0.45, 12.0, 0.0, 0.0
        self.redraw()

    def on_left_click(self, event):
        best_idx, best_dist = -1, 12.0
        for idx, v in enumerate(self.vertices):
            sx, sy, _ = self.project_3d(*v)
            d = math.hypot(event.x - sx, event.y - sy)
            if d < best_dist:
                best_dist, best_idx = d, idx
        if best_idx != -1:
            self.select_vertex(best_idx)

    def select_vertex(self, idx):
        self.selected_vertex = idx
        vx, vy, vz = self.vertices[idx]
        self.var_vx.set('{:.4f}'.format(vx))
        self.var_vy.set('{:.4f}'.format(vy))
        self.var_vz.set('{:.4f}'.format(vz))
        self.redraw()

    def on_table_select(self, event):
        sel = self.tree.selection()
        if sel:
            first_sel, *_ = sel
            idx_str, *_ = self.tree.item(first_sel, 'values')
            self.select_vertex(int(idx_str))

    def apply_vertex_edit(self):
        if 0 <= self.selected_vertex < len(self.vertices):
            try:
                self.save_state()
                self.vertices[self.selected_vertex] = [float(self.var_vx.get()), float(self.var_vy.get()), float(self.var_vz.get())]
                self.refresh_all()
            except ValueError:
                messagebox.showerror('Input Error', 'Koordinat harus berupa angka.')

    def translate_mesh(self, dx, dy, dz):
        self.save_state()
        for i, (vx, vy, vz) in enumerate(self.vertices):
            self.vertices[i] = [vx + dx, vy + dy, vz + dz]
        self.refresh_all()

    def rotate_mesh_y(self, deg):
        self.save_state()
        c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
        for i, (vx, vy, vz) in enumerate(self.vertices):
            self.vertices[i] = [vx * c - vz * s, vy, vx * s + vz * c]
        self.refresh_all()

    def rotate_mesh_x(self, deg):
        self.save_state()
        c, s = math.cos(math.radians(deg)), math.sin(math.radians(deg))
        for i, (vx, vy, vz) in enumerate(self.vertices):
            self.vertices[i] = [vx, vy * c - vz * s, vy * s + vz * c]
        self.refresh_all()

    def scale_mesh(self, factor):
        self.save_state()
        for i, (vx, vy, vz) in enumerate(self.vertices):
            self.vertices[i] = [vx * factor, vy * factor, vz * factor]
        self.refresh_all()

    def refresh_all(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for idx, (vx, vy, vz) in enumerate(self.vertices):
            self.tree.insert('', tk.END, values=(idx, '{:.4f}'.format(vx), '{:.4f}'.format(vy), '{:.4f}'.format(vz)))
        self.lbl_status_top.config(text='Vertices: {} | Edges: {} | Faces: {} | Undo: {}'.format(len(self.vertices), len(self.edges), len(self.faces), len(self.undo_stack)))
        if 0 <= self.selected_vertex < len(self.vertices):
            self.select_vertex(self.selected_vertex)
            return
        self.redraw()

    def import_obj(self):
        path = filedialog.askopenfilename(title='Import .OBJ', filetypes=[('Wavefront OBJ (*.obj)', '*.obj')])
        if not path:
            return
        verts, faces, edges_set = [], [], set()
        try:
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    parts = line.strip().split()
                    if not parts:
                        continue
                    tag, *rest = parts
                    if tag == 'v' and len(rest) >= 3:
                        xs, ys, zs, *_ = rest
                        verts.append([float(xs), float(ys), float(zs)])
                        continue
                    if not tag == 'f':
                        continue
                    if not len(rest) >= 3:
                        continue
                    face_idx = []
                    for p in rest:
                        v_token, *_ = p.split('/')
                        face_idx.append(int(v_token) - 1)
                    faces.append(face_idx)
                    for i in range(len(face_idx)):
                        edges_set.add(tuple(sorted((face_idx[i], face_idx[(i + 1) % len(face_idx)]))))
                    continue
        except Exception as e:
            messagebox.showerror('Error Import OBJ', str(e))
            return
        try:
            self.save_state()
            self.vertices, self.faces, self.edges, self.selected_vertex = verts, faces, list(edges_set), -1
            self.refresh_all()
            messagebox.showinfo('Sukses', f'Berhasil memuat {len(verts)} vertices dari file .OBJ!')
        except Exception as e:
            messagebox.showerror('Error Import OBJ', str(e))
            return

    def export_obj(self):
        path = filedialog.asksaveasfilename(title='Export .OBJ', defaultextension='.obj', filetypes=[('Wavefront OBJ (*.obj)', '*.obj')])
        if not path:
            return
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write('# Exported from Semarbroka 3D Mesh Editor\n')
                for vx, vy, vz in self.vertices:
                    f.write(f'v {vx:.6f} {vy:.6f} {vz:.6f}\n')
                for face in self.faces:
                    f.write('f ' + ' '.join((str(idx + 1) for idx in face)) + '\n')
            messagebox.showinfo('Sukses', 'Model 3D berhasil disimpan ke format .OBJ!')
        except Exception as e:
            messagebox.showerror('Error Export OBJ', str(e))
            return


if __name__ == '__main__':
    root = tk.Tk()
    app = Semarbroka3DEditor(root)
    root.mainloop()
